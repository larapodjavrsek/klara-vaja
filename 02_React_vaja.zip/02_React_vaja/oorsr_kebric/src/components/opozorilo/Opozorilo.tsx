import React from "react";
import "./Opozorilo.css"
const Opozorilo = () => {
    return(
        <h3 id="pozor">
            Ekipa ima premalo igralcev.
        </h3>
    );
}

export default Opozorilo;