import React, {useState} from "react";
import {useNavigate} from "react-router";
import {Ekipa} from "../../models/Ekipa";
import {IgralecModel} from "../../models/Oseba";
import {DodajIgralcaProps} from "../../models/DodajIgralcaProps";
import {Simulate} from "react-dom/test-utils";
import submit = Simulate.submit;

interface DodajProps {
    onAdd: (igr: IgralecModel) => any
}

const DodajIgralca = (add: DodajProps) => {

    /* 2. način
    {props}: {props: DodajIgralcaProps}
    const {ekipa, funDodaj} = props;
     */
    const initialState: IgralecModel = {
        id: 0,
        ime: '',
        priimek: '',
        visina: 0,
        teza: 0,
        poskodovan: false,
        letoRojstva: 2000,
        krajRojstva: ''
    }
    const [igralec, setIgralec] = useState<IgralecModel>(initialState);


    const handleSubmit = (event: { preventDefault: () => void; }) => {
        event.preventDefault();
        add.onAdd(igralec);
        setIgralec(initialState);
    }

    const handleChange = (e: { target: { value: any; name: any; }; }) => {
        const { value, name } = e.target;
        setIgralec((prevState: IgralecModel) => {
            const nextState = {
                ...prevState,
                [name]: value
            };
            console.log(nextState);
            return nextState;
        })
    }


    return(
        <form onSubmit={handleSubmit}>
            <input name="ime" value={igralec.ime} onChange={handleChange}/>
            <button type="submit">potrdi</button>
        </form>

        /*
        <div>
            <p>Dodaj igralca: </p>
            Ime: <input type="text" value={ime} onChange={(e) => setIme(e.target.value)}/><br />
            Priimek: <input value={priimek} onChange={(e) => setPriimek(e.target.value)}/><br />
            Visina: <input value={visina} onChange={(e) => setVisina(parseInt(e.target.value))} /><br />
            Teza: <input value={teza} onChange={(e) => setTeza(parseInt(e.target.value))} /><br />
            Poskodovan: <input value={poskodovan ? "da" : "ne"} onChange={(e) => setPoskodovan((e.target.value === "da"))} /><br />
            Leto rojstva: <input value={leto} onChange={(e) => setLetoRojstva(parseInt(e.target.value))} /><br />
            Kraj: <input value={kraj} onChange={(e) => setKraj(e.target.value)} /><br />
            <button onClick={dodajIgralca}>Dodaj igralca</button>
            </div>

         */
    )
}

export default DodajIgralca;