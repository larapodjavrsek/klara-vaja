import React, {useEffect, useState} from "react";
import { IgralecModel } from "../../models/Oseba"
import Igralec from "../igralec/Igralec";
import "./Telo.css";
import {Ekipa} from "../../models/Ekipa";
import {useParams} from "react-router";
import Menu from "../menu/Menu";
import Opozorilo from "../opozorilo/Opozorilo";
import Info from "../info/Info";
import DodajIgralca from "./DodajIgralca";
import {DodajIgralcaProps} from "../../models/DodajIgralcaProps";

const Telo = ({vseEkipe}: {vseEkipe: Ekipa []}) => {
    const { id } = useParams();
    let ekipa: Ekipa | undefined;
    if (typeof id === "string") {
        const izbranId: number = parseInt(id);
        vseEkipe.forEach((e: Ekipa) => {
            if(e.id === izbranId){
                ekipa = e;
                console.log("set ekipa")
            }
        })
    } else ekipa = undefined;

    const initialState: IgralecModel[] = [];

    const [vsi, setVsi] = useState<IgralecModel[]>((ekipa === undefined) ? initialState : ekipa.igralci);

    useEffect(() => {
        console.log(ekipa?.izpisiPodatke())

    }, [handleAdding]);





    function dodajNovIgralca(igr: IgralecModel){
        /*
        if(igr !== undefined){
            const noviIgr: IgralecModel [] = [...vsiIgr, igr]
            setVsiIgr(noviIgr);
            setStIgr(noviIgr.length);
            ekipa?.dodajIgralca(igr);
            console.log(ekipa?.izpisiPodatke())
        }

         */
    }
    function handleAdding (player: IgralecModel){
/*
        console.log("hendlamo")
        setVsi((prevState: IgralecModel[]) => {
            const nextState = [
                ...prevState,
                player
            ]
            console.log("V TELESU" + nextState);
            return nextState;


        });

*/
        if(ekipa !== undefined){
            player.id = ekipa?.igralci.length + 1;
            console.log("ja")
            ekipa?.dodajIgralca(player);
            setVsi([...vsi, player])
        }

    }
    return(
        <>
            <Menu props={ekipa?.ime || "ekipa"} />
            <div id="telo">
                Igralci (st. vseh: {ekipa?.igralci.length}): <br />
                {ekipa?.igralci.map(igralec => {
                    return(
                        <ul key={igralec.id}>
                            <Igralec igra={igralec} />
                        </ul>
                    );
                })}
                {ekipa?.igralci.length || 11 < 11 ? <Opozorilo />: <Info />}
            </div>
            <DodajIgralca onAdd={handleAdding} />
        </>
    );
}

export default Telo;