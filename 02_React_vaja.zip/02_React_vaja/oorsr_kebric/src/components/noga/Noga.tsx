import React from "react";
import "./Noga.css";

const Noga = () => {
  return(
      <footer id="noga">
          Avtor: Klara Kebrič <br />
          Predmet: OORSR <br />
          Leto: 2023
      </footer>
  );
}
export default Noga;