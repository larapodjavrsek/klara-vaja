import React from "react";
import "./Info.css"
const Info = () => {
  return(
      <h3 id="info">
          Ekipa ima dovolj igralcev.
      </h3>
  );
}

export default Info;