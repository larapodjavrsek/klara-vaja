import React from "react";
import "./Menu.css"
const Menu = ({props}: {props: string}) => {
  return(
      <h1 id="naslov">
          Ekipa: {props}
      </h1>
  );
}

export default Menu;