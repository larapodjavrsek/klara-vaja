import React from "react";
import {IgralecModel} from "../../models/Oseba";

const Igralec = ({igra}: {igra: IgralecModel}) => {
    return(
        <li>
            {"Ime: " + igra.ime + " Priimek: " + igra.priimek} <br/>
            {"Višina: " + igra.visina + "cm Teža: " + igra.teza}kg <br/>
            {"Id: " + igra.id + " Poškodovan: " + igra.poskodovan} <br/>
        </li>
    );
}
export default Igralec;