import React, {useState} from "react";
import IEkipa from "../../models/IEkipa";
interface ObrazecProps {
    onAdd: (ekipa: IEkipa) => any
}
const ObrazecEkipa = (props: ObrazecProps) => {
    const initialState= {
        id: 0,
        naslov: 'naslov'
    }

    const [ekipa, setEkipa] = useState<IEkipa>(initialState)
    const handleSubmit = (event: { preventDefault: () => void; }) => {
        event.preventDefault();
        props.onAdd(ekipa)
    }
    const handleChange = (e: { target: { value: any; }; }) => {
        const { value } = e.target;
        setEkipa((prevState: IEkipa) => {
            const nextState = {
                ...prevState,
                id: prevState.id++,
                naslov: value
            };
            return nextState;
        })
    }
    return(
        <form onSubmit={handleSubmit}>
            Dodaj ekipo:
            <input name="naslov" value={ekipa.naslov} onChange={handleChange}/>
            <button type="submit">Submit</button>
        </form>
    )
}
export default ObrazecEkipa;