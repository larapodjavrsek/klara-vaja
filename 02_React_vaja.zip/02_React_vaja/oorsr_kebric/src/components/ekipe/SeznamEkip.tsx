import React from "react";
import {useNavigate, useParams} from "react-router";
import Telo from "../telo/Telo";
import {Ekipa} from "../../models/Ekipa";
import {Link} from "react-router-dom";

const SeznamEkip = ({ ekipe }: { ekipe: Ekipa[] }) => {
    const navigate = useNavigate();
    return(
        <div>
            { /*ekipe.map(ekipa => {
                return(<>
                    {console.log(ekipa.id)}
                    <button key={ekipa.id} onClick={() => navigate(`/ekipa/${ekipa.id}`)}>{ekipa.ime}</button>
                </>);
            }) */
            ekipe.map((ekipa) => {
                return(
                        <Link key={ekipa.id} to={`/ekipa/${ekipa.id}`}>
                           [ {ekipa.ime} ]
                        </Link>
                    )
            })
            }
        </div>
    )
}

export default SeznamEkip;