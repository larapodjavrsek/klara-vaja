import React from "react";
import {Route, Routes} from "react-router";
import Telo from "../components/telo/Telo";
import SeznamEkip from "../components/ekipe/SeznamEkip";
import {Ekipa} from "../models/Ekipa";

const Routing = ({ekipe}: {ekipe: Ekipa []}) => {
  return(
      <Routes>
          <Route path="/" element={<SeznamEkip ekipe={ekipe} />}/>
          <Route path="/ekipa/:id" element={<Telo vseEkipe={ekipe} />} />
          <Route path="*" element="Error. Page not found." />
      </Routes>
  );
}

export default Routing;