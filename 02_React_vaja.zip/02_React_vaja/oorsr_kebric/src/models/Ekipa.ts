import { Funkcionar, IgralecModel } from "./Oseba";
class Ekipa {
    private _ime: string;
    private _id: number;
    private _letoUstanovitve: number;
    private _direktor: Funkcionar;
    private _trener: Funkcionar;
    private _igralci: IgralecModel [];
    public constructor(ime: string, id: number, letoUstanovitve: number, direktor: Funkcionar, trener: Funkcionar, igralci: IgralecModel []) {
        this._ime = ime;
        this._id = id;
        this._letoUstanovitve = letoUstanovitve;
        this._direktor = direktor;
        this._trener = trener;
        this._igralci = igralci;
    }
    dodajIgralca(igralec: IgralecModel): void {
        this.igralci.push(igralec);
    }

    posodobiIgralca(igralec: IgralecModel): void {
        /*
        const izbran: Igralec [] = this.igralci.filter((igralec) => {
            if(igralec.id === novId)
                return igralec;

        });

        const izbran: Igralec [] = this.igralci.filter(igralec => igralec.id === novId);
        console.log(izbran[0])
         */
        const novId: number = igralec.id;
        const izbran: number | undefined = this.igralci.findIndex(igr => igr.id === novId);
        /*
        if(izbran === undefined)
            return;
         */
        if(izbran === -1)
            return;

        this.igralci[izbran] = igralec;
        /*
        destructioring
        this.object = value;
         */
    }
    odstraniIgralca(id: number): void {
        this.igralci = this.igralci.filter(igralec => igralec.id !== id);
    }
    //pri direktorju in trenerju bi lahko izpisali vse podatke na podoben način
    izpisiPodatke(): string {
        return `
            Ime: [${this.ime}], Leto ustanovitve: [${this.letoUstanovitve}]
            Direktor: [${this.direktor.ime} ${this.direktor.priimek}, vloga: ${this.direktor.vloga}], Trener: [${this.trener.ime} ${this.trener.priimek}, vloga: ${this.trener.vloga}]
            Igralci: ${this.vrniIgralce()}
        `;
    }
    vrniIgralce(): string {
        let vsi: string = ``;
        this.igralci.forEach( igralec =>
            vsi += `[${igralec.ime} ${igralec.priimek} - ${igralec.krajRojstva} ${igralec.letoRojstva}
                ${igralec.visina}cm ${igralec.teza}kg poskodovan: ${igralec.poskodovan}
                ID: ${igralec.id}]
                `)
        return vsi;
    }

    /*
        namesto get getIme(): string --> klic: ekipa.getIme() je bolj prirocno, da osnovne atribute preimenujemo
        ime -> _ime ter getterje in setterje preimenujemo: namesto getIme() samo ime() - obcutek, da razred nima private atributov
     */
    get ime(): string {
        return this._ime;
    }

    set ime(value: string) {
        this._ime = value;
    }

    get letoUstanovitve(): number {
        return this._letoUstanovitve;
    }

    set letoUstanovitve(value: number) {
        this._letoUstanovitve = value;
    }

    get direktor(): Funkcionar {
        return this._direktor;
    }

    set direktor(value: Funkcionar) {
        this._direktor = value;
    }

    get trener(): Funkcionar {
        return this._trener;
    }

    set trener(value: Funkcionar) {
        this._trener = value;
    }

    get igralci(): IgralecModel[] {
        return this._igralci;
    }

    set igralci(value: IgralecModel[]) {
        this._igralci = value;
    }

    get id(): number {
        return this._id;
    }

    set id(value: number) {
        this._id = value;
    }
}

export { Ekipa };