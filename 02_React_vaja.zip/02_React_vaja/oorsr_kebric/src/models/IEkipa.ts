interface IEkipa {
    id: number,
    naslov: string
}
export default IEkipa;