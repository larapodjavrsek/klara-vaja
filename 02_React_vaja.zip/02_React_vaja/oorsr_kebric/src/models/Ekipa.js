"use strict";
exports.__esModule = true;
exports.Ekipa = void 0;
var Ekipa = /** @class */ (function () {
    function Ekipa(ime, id, letoUstanovitve, direktor, trener, igralci) {
        this._ime = ime;
        this._id = id;
        this._letoUstanovitve = letoUstanovitve;
        this._direktor = direktor;
        this._trener = trener;
        this._igralci = igralci;
    }
    Ekipa.prototype.dodajIgralca = function (igralec) {
        this.igralci.push(igralec);
    };
    Ekipa.prototype.posodobiIgralca = function (igralec) {
        /*
        const izbran: Igralec [] = this.igralci.filter((igralec) => {
            if(igralec.id === novId)
                return igralec;

        });

        const izbran: Igralec [] = this.igralci.filter(igralec => igralec.id === novId);
        console.log(izbran[0])
         */
        var novId = igralec.id;
        var izbran = this.igralci.findIndex(function (igr) { return igr.id === novId; });
        /*
        if(izbran === undefined)
            return;
         */
        if (izbran === -1)
            return;
        this.igralci[izbran] = igralec;
        /*
        destructioring
        this.object = value;
         */
    };
    Ekipa.prototype.odstraniIgralca = function (id) {
        this.igralci = this.igralci.filter(function (igralec) { return igralec.id !== id; });
    };
    //pri direktorju in trenerju bi lahko izpisali vse podatke na podoben način
    Ekipa.prototype.izpisiPodatke = function () {
        return "\n            Ime: [".concat(this.ime, "], Leto ustanovitve: [").concat(this.letoUstanovitve, "]\n            Direktor: [").concat(this.direktor.ime, " ").concat(this.direktor.priimek, ", vloga: ").concat(this.direktor.vloga, "], Trener: [").concat(this.trener.ime, " ").concat(this.trener.priimek, ", vloga: ").concat(this.trener.vloga, "]\n            Igralci: ").concat(this.vrniIgralce(), "\n        ");
    };
    Ekipa.prototype.vrniIgralce = function () {
        var vsi = "";
        this.igralci.forEach(function (igralec) {
            return vsi += "[".concat(igralec.ime, " ").concat(igralec.priimek, " - ").concat(igralec.krajRojstva, " ").concat(igralec.letoRojstva, "\n                ").concat(igralec.visina, "cm ").concat(igralec.teza, "kg poskodovan: ").concat(igralec.poskodovan, "\n                ID: ").concat(igralec.id, "]\n                ");
        });
        return vsi;
    };
    Object.defineProperty(Ekipa.prototype, "ime", {
        /*
            namesto get getIme(): string --> klic: ekipa.getIme() je bolj prirocno, da osnovne atribute preimenujemo
            ime -> _ime ter getterje in setterje preimenujemo: namesto getIme() samo ime() - obcutek, da razred nima private atributov
         */
        get: function () {
            return this._ime;
        },
        set: function (value) {
            this._ime = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Ekipa.prototype, "letoUstanovitve", {
        get: function () {
            return this._letoUstanovitve;
        },
        set: function (value) {
            this._letoUstanovitve = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Ekipa.prototype, "direktor", {
        get: function () {
            return this._direktor;
        },
        set: function (value) {
            this._direktor = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Ekipa.prototype, "trener", {
        get: function () {
            return this._trener;
        },
        set: function (value) {
            this._trener = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Ekipa.prototype, "igralci", {
        get: function () {
            return this._igralci;
        },
        set: function (value) {
            this._igralci = value;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Ekipa.prototype, "id", {
        get: function () {
            return this._id;
        },
        set: function (value) {
            this._id = value;
        },
        enumerable: false,
        configurable: true
    });
    return Ekipa;
}());
exports.Ekipa = Ekipa;
