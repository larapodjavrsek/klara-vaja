import {Ekipa} from "./Ekipa";
import {IgralecModel} from "./Oseba";

interface DodajIgralcaProps {
    ekipa: Ekipa | undefined;
    funDodaj: (igr: IgralecModel) => void;
}

export type { DodajIgralcaProps };