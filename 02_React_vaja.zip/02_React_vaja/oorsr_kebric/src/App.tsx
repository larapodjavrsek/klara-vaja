import React from 'react';
import './App.css';
import Menu from "./components/menu/Menu";
import Telo from "./components/telo/Telo";
import Opozorilo from "./components/opozorilo/Opozorilo";
import Info from "./components/info/Info";
import Noga from "./components/noga/Noga";
import {Ekipa} from "./models/Ekipa";
import {Funkcionar, IgralecModel} from "./models/Oseba";
import Routing from "./routing/Routing";
import {BrowserRouter, Outlet} from "react-router-dom";
import SeznamEkip from "./components/ekipe/SeznamEkip";
import {vseEkipe} from "./index";

function App() {


  /*
   <div>
        <Menu props={ekipa1.ime} />
        <Routing ekipe={[ekipa1, ekipa2]} />
        {ekipa1.igralci.length < 11 ? <Opozorilo />: <Info />}
        <Noga />
    </div>


    <BrowserRouter>
            <Routing ekipe={[ekipa1, ekipa2]} />
        </BrowserRouter>
   */

  return (
    <>
        <h1>Vse ekipe</h1>
        <SeznamEkip ekipe={vseEkipe} />
        <Outlet />
        <Noga />
    </>
  );
}

export default App;
