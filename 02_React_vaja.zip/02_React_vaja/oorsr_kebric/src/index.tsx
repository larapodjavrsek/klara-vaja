import React, {useState} from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import {createBrowserRouter, RouterProvider} from "react-router-dom";
import Telo from "./components/telo/Telo";
import {Funkcionar, IgralecModel} from "./models/Oseba";
import {Ekipa} from "./models/Ekipa";
import IEkipa from "./models/IEkipa";
import ObrazecEkipa from "./components/ekipe/ObrazecEkipa";

const igralci: IgralecModel[] = [
    {
        id: 1,
        ime: "alen",
        priimek: "torek",
        visina: 200,
        teza: 85,
        poskodovan: false,
        letoRojstva: 2002,
        krajRojstva: "Maribor"
    },
    {
        id: 2,
        ime: "nik",
        priimek: "sreda",
        visina: 190,
        teza: 80,
        poskodovan: false,
        letoRojstva: 2001,
        krajRojstva: "Maribor"
    },
    {
        id: 3,
        ime: "luka",
        priimek: "petek",
        visina: 180,
        teza: 75,
        poskodovan: true,
        letoRojstva: 2001
    },
    {
        id: 4,
        ime: "luka",
        priimek: "petek",
        visina: 180,
        teza: 75,
        poskodovan: true,
        letoRojstva: 2001
    },
    {
        id: 5,
        ime: "luka",
        priimek: "petek",
        visina: 180,
        teza: 75,
        poskodovan: true,
        letoRojstva: 2001
    },
    {
        id: 6,
        ime: "luka",
        priimek: "petek",
        visina: 180,
        teza: 75,
        letoRojstva: 2001,
        poskodovan: true
    },
    {
        id: 7,
        ime: "luka",
        priimek: "petek",
        letoRojstva: 2001,
        visina: 180,
        teza: 75,
        poskodovan: true
    },
    {
        id: 8,
        ime: "luka",
        priimek: "petek",
        letoRojstva: 2001,
        visina: 180,
        teza: 75,
        poskodovan: true
    },
    /*
    {
        id: 9,
        ime: "luka",
        priimek: "petek",
        letoRojstva: 2001,
        visina: 180,
        teza: 75,
        poskodovan: true
    },
    {
        id: 10,
        ime: "luka",
        priimek: "petek",
        letoRojstva: 2001,
        visina: 180,
        teza: 75,
        poskodovan: true
    },
    {
        id: 11,
        ime: "luka",
        priimek: "petek",
        letoRojstva: 2001,
        visina: 180,
        teza: 75,
        poskodovan: true
    },
    {
        id: 12,
        ime: "luka",
        priimek: "petek",
        letoRojstva: 2001,
        visina: 180,
        teza: 75,
        poskodovan: true
    }

     */
]
const igralci2: IgralecModel[] = [
    {
        id: 1,
        ime: "drugi",
        priimek: "torek",
        visina: 200,
        teza: 85,
        poskodovan: false,
        letoRojstva: 2002,
        krajRojstva: "Maribor"
    },
    {
        id: 2,
        ime: "tretji",
        priimek: "sreda",
        visina: 190,
        teza: 80,
        poskodovan: false,
        letoRojstva: 2001,
        krajRojstva: "Maribor"
    },
    {
        id: 3,
        ime: "novi",
        priimek: "petek",
        visina: 180,
        teza: 75,
        poskodovan: true,
        letoRojstva: 2001
    }
]
const dir: Funkcionar = {
    vloga: "Direktor",
    veljavnost: 2000,
    ime: "Rok",
    priimek: "Torek",
    letoRojstva: 1980,
    krajRojstva: "Ljubljana",
    id: 23

}
const tre: Funkcionar = {
    vloga: "Trener",
    veljavnost: 2010,
    ime: "Janez",
    priimek: "Petek",
    letoRojstva: 1970,
    krajRojstva: "Maribor",
    id: 24
}
const ekipa1: Ekipa = new Ekipa(
    "ekipa1", 1, 2000, dir, tre, igralci
)

const ekipa2: Ekipa = new Ekipa(
    "ekipa2", 2, 2005, dir, tre, igralci2
);
export const vseEkipe: Ekipa[] = [ekipa1, ekipa2];
const team1: IEkipa = {
    id: 0,
    naslov: 'Ekipca'
}
const Vmesni = () => {

    const [teams, setTeams]  = useState<IEkipa[]>([team1]);
    const handleAdd = (ekipa: IEkipa) => {
        let novi = Array.from(teams);
        //let drugi = [...seznamEkip];
        novi.push(ekipa);
        setTeams(novi);

    }
    return(
        <>
            {teams.map( team => {
                return (
                    <li key={team.id}>
                        {team.naslov}
                    </li>
                );
            })}
            <ObrazecEkipa onAdd={handleAdd} />
        </>
    )

}


const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
const router = createBrowserRouter([
    {
        path: "/",
        element: <App />,
        children: [
            {
                path: "ekipa/:id",
                element: <Telo vseEkipe={[ekipa1, ekipa2]} />
            },
        ]
    },
    {
        path: "*",
        element: "Error. Page not found."
    }
])

root.render(
  <React.StrictMode>
      <p>Dodajanje ekip:</p>
      <Vmesni />
      <RouterProvider router={router} />
  </React.StrictMode>
);
